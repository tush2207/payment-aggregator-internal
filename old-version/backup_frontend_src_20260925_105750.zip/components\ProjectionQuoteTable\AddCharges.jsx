import {
    Box,
    Button,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    TextField
} from "@mui/material";
import { useEffect, useState } from "react";

import { PROJECTION_CAL_DETAILS, PROJECTION_COLUMNS_FOR_PA } from "&src/constants/PaymentAggregratorConstant";
import aggregatorProjections from "&src/services/aggregatorProjections";
import DialogWithHeader from "../Dialog/DialogWithHeader";
import FullScreenLoader from "../Loaders/FullScreenLoader";
import useStatusWiseAlert from "../ToastNotifications/useStatusWiseAlert";
import { PERCENTAGE, RS } from "&src/utils";


const AddCharges = ({
    applicationDetails,
    aggregatorId,
    openModal,
    setOpenModal,
    onSaveSuccess
}) => {
    const { applicationId } = applicationDetails || {};
    const { errorNotification, successNotification } = useStatusWiseAlert();
    const [loading, setLoading] = useState(false);
    const [errorRowIds, setErrorRowIds] = useState([]);
    const [allCharges, setAllCharges] = useState([]);

    // ---------------------- Initialize Data ----------------------
    useEffect(() => {
        if (PROJECTION_CAL_DETAILS) {
            // Preserve all existing fields and ensure rate/unit exist
            const initialized = PROJECTION_CAL_DETAILS.map((q, i) => ({
                id: q.id ?? i + 1,
                allow: q.allow,
                transactionType: q.transactionType,
                chargesProposed: q.chargesProposed ?? 0.0,
                bankUnit: RS
            }));
            setAllCharges(initialized);
        }
    }, []);

    const handleChanges = (transactionType, value) => {
        setAllCharges((prev) =>
            prev.map((row) =>
                row.transactionType === transactionType
                    ? { ...row, chargesProposed: parseFloat(value) }
                    : row
            )
        );
    };

    const handleRateTypeChange = (transactionType, value) => {
        setAllCharges((prev) =>
            prev.map((row) =>
                row.transactionType === transactionType
                    ? { ...row, bankUnit: value }
                    : row
            )
        );
    };


    // ---------------------- Save All ----------------------
    const saveAllChareges = async () => {
        setLoading(true);
        try {
            await aggregatorProjections.updateProjectionByApplication(applicationId, allCharges);
            successNotification(" Bank charges updated and projections recalculated successfully.");
            setOpenModal(false);
            if (onSaveSuccess) {
                await onSaveSuccess();
            }
            setLoading(false);
        } catch (err) {
            setLoading(false);
            console.error("Error in saveAllChareges:", err);
            errorNotification(
                err?.response?.data?.message ||
                err?.message ||
                " Something went wrong. Please try again."
            );
        }
    };

    // ---------------------- Render ----------------------
    return (
        <Box p={2}>
            <DialogWithHeader
                maxWidth="sm"
                open={openModal}
                onClose={() => setOpenModal(!openModal)}
                headerText={`Add Charges As Per Projections`}
            >
                {loading && <FullScreenLoader />}

                <Table size="small" sx={{ border: "1px solid #e0e0e0" }}>
                    <TableHead>
                        <TableRow>
                            {PROJECTION_COLUMNS_FOR_PA.map((col, idx) => (
                                <TableCell key={idx} sx={{ fontWeight: 600, fontSize: "13px" }}>
                                    {col}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>

                    <TableBody>
                        {allCharges?.length ? (
                            allCharges.map((row, i) => (
                                <TableRow key={row.id}>
                                    <TableCell>{i + 1}</TableCell>
                                    <TableCell width="50%">{row.transactionType}</TableCell>

                                    {row.allow ? (
                                        <TableCell>
                                            <TextField
                                                name="chargesProposed"
                                                size="small"
                                                // placeholder="Enter Charges"
                                                variant="outlined"
                                                type="text"
                                                value={row.charge}
                                                error={errorRowIds.includes(row.id)}
                                                helperText={
                                                    errorRowIds.includes(row.id)
                                                        ? "Required"
                                                        : ""
                                                }
                                                onChange={(e) => {
                                                    const val = e.target.value;
                                                    if (
                                                        val === "" ||
                                                        /^\d{0,3}(\.\d{0,3})?$/.test(val)
                                                    ) {
                                                        handleChanges(row.transactionType, val);
                                                    }
                                                }}
                                                inputProps={{ style: { textAlign: "right" } }}
                                                InputProps={{
                                                    startAdornment: (
                                                        <TextField
                                                            select
                                                            value={row.bankUnit}
                                                            onChange={(e) => handleRateTypeChange(row.transactionType, e.target.value)}
                                                            variant="standard"
                                                            size="small"
                                                            sx={{
                                                                minWidth: 45,
                                                                "& .MuiSelect-select": { padding: "2px 8px" },
                                                            }}
                                                        >
                                                            <MenuItem value={RS}>{RS}</MenuItem>
                                                            <MenuItem value={PERCENTAGE}>{PERCENTAGE}</MenuItem>
                                                        </TextField>
                                                    ),
                                                }}

                                            />
                                        </TableCell>
                                    ) : (
                                        <TableCell />
                                    )}
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={3} align="center">
                                    No data available
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>

                <Box display="flex" justifyContent="end" mt={1}>
                    <Button variant="contained" size="small" onClick={saveAllChareges}>
                        Submit Charges
                    </Button>
                </Box>
            </DialogWithHeader>
        </Box>
    );
};

export default AddCharges;
