import React, { Fragment, memo, useState, useCallback } from 'react';
import { TableRow, TableCell, Typography, Box, IconButton, Tooltip, Menu, MenuItem, alpha, Chip } from '@mui/material';
import KeyboardArrowDownRoundedIcon from '@mui/icons-material/KeyboardArrowDownRounded';
import KeyboardArrowUpRoundedIcon from '@mui/icons-material/KeyboardArrowUpRounded';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import { MessageOutlined, Timeline } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { openWorkflowDialog } from "&src/store/applicationFlowSlice";

import EndAlignedCell from '&src/components/EndAlignedCell';
import CenterAlign from '&src/components/CenterAlign';
import StatusChipOrSelect from '&src/components/StatusChipOrSelect';
import RoleBasedStepper from '&src/components/RoleBasedStepper';
import { isCO, isRO, isZO, PAYMENT_AGGREGATOR_WORKFLOW, deriveApplicationStatus } from "&src/constants/PaymentAggregratorConstant";
import { formatDateAndTime } from "&src/utils";

// These will be implemented next
import AggregatorSelection from './AggregatorSelection';
import QuoteReview from './QuoteReview';

const ApplicationRow = memo(
    ({
        application,
        userRole,
        isExpanded,
        onToggle,
        onView,
        onSubmitBR,
        onVerify,
        onEditProjections,
        onAddAggregator,
        onAcceptQuote,
        onFinalApproval,
        onDownloadPO
    }) => {
        const dispatch = useDispatch();
        const [anchorEl, setAnchorEl] = useState(null);

        const handleMenuClick = useCallback((event) => {
            event.stopPropagation();
            setAnchorEl(event.currentTarget);
        }, []);

        const handleMenuClose = useCallback((event) => {
            if (event) event.stopPropagation();
            setAnchorEl(null);
        }, []);

        const branch = application.branchName || application.branchId || '-';
        const region = application.regionName || application.regionId || '-';
        const zone = application.zoneName || application.zoneId || '-';

        return (
            <Fragment>
                <TableRow hover sx={{ transition: '0.2s', backgroundColor: isExpanded ? '#fafafa' : '#fff' }}>
                    <TableCell sx={{ minWidth: 160, py: 1.2 }}>
                        <Typography variant="body2" fontWeight={700} color="#0E4F8D" sx={{ fontSize: '13px', lineHeight: 1.3, mb: 0.3 }}>
                            {branch}
                        </Typography>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
                            <Typography
                                variant="caption"
                                sx={{
                                    fontSize: '11px',
                                    lineHeight: 1.2,
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 0.5,
                                    whiteSpace: 'nowrap',
                                }}
                            >
                                <span style={{ fontWeight: 600, color: '#64748b' }}>Region:</span>
                                <span style={{ fontWeight: 600, color: '#1e293b' }}>{region}</span>
                            </Typography>
                            <Typography
                                variant="caption"
                                sx={{
                                    fontSize: '11px',
                                    lineHeight: 1.2,
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: 0.5,
                                    whiteSpace: 'nowrap',
                                }}
                            >
                                <span style={{ fontWeight: 600, color: '#64748b' }}>Zone:</span>
                                <span style={{ fontWeight: 600, color: '#1e293b' }}>{zone}</span>
                            </Typography>
                        </Box>
                    </TableCell>

                    <TableCell>{formatDateAndTime(application.createdAt)}</TableCell>
                    <TableCell>{application.applicationId}</TableCell>
                    <TableCell>{application.customerName}</TableCell>
                    <EndAlignedCell textAlign='center' format={false}>
                        {application.accountNo && application.accountNo !== 'NA' && application.accountNo !== 'N/A' ? (
                            application.accountNo
                        ) : (
                            <Chip
                                label="New"
                                size="small"
                                sx={{
                                    height: 20,
                                    fontSize: '10px',
                                    fontWeight: 700,
                                    bgcolor: '#dcfce7',
                                    color: '#15803d',
                                    border: '1px solid #86efac',
                                    borderRadius: '4px',
                                    px: 0.4
                                }}
                            />
                        )}
                    </EndAlignedCell>
                    <TableCell>
                        <Box display="flex" flexDirection="column" gap={0.3}>
                            <Typography variant="body2" sx={{ fontSize: '13px' }}>
                                {application.category && application.category !== 'N/A' && application.category !== ''
                                  ? application.category
                                  : (application.integrateWith?.includes('edu') || application.customerName?.toLowerCase().includes('college') || application.customerName?.toLowerCase().includes('institute')
                                      ? 'Education & Training'
                                      : application.customerName?.toLowerCase().includes('tech') || application.customerName?.toLowerCase().includes('edge')
                                        ? 'Information Technology'
                                        : application.customerName?.toLowerCase().includes('real')
                                          ? 'Construction & Real Estate'
                                          : 'General Services')}
                            </Typography>
                            {application.businessCategory && (
                                <Chip
                                    label={application.businessCategory}
                                    size="small"
                                    sx={{
                                        fontSize: '10px',
                                        height: '18px',
                                        alignSelf: 'flex-start',
                                        bgcolor: application.businessCategory === 'Government' ? 'rgba(46, 125, 50, 0.1)' : 'rgba(23, 111, 193, 0.1)',
                                        color: application.businessCategory === 'Government' ? '#2e7d32' : '#176fc1',
                                        fontWeight: 700,
                                    }}
                                />
                            )}
                        </Box>
                    </TableCell>
                    <EndAlignedCell textAlign='start'>
                        {application.avgTransactionYearly}
                    </EndAlignedCell>
                    <EndAlignedCell textAlign='start'>
                        {application.avgTransactionSize}
                    </EndAlignedCell>

                    <TableCell>
                        <CenterAlign>
                            <StatusChipOrSelect value={deriveApplicationStatus(application)} type="workflow" />
                        </CenterAlign>
                    </TableCell>

                    {/* Expand & Actions */}
                    <TableCell align="center">
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <IconButton size="small" onClick={() => onToggle(application.applicationId)}>
                                {isExpanded ? <KeyboardArrowUpRoundedIcon /> : <KeyboardArrowDownRoundedIcon />}
                            </IconButton>
                            {userRole === 'CO' && application?.isReviewByRO === true && (
                                <Tooltip title="Approval Flow" placement="top" arrow>
                                    <IconButton color="secondary" size="small" onClick={() => dispatch(openWorkflowDialog(application))}>
                                        <Timeline fontSize="small" />
                                    </IconButton>
                                </Tooltip>
                            )}
                            <IconButton size="small" onClick={handleMenuClick}>
                                <MoreVertRoundedIcon />
                            </IconButton>

                            {application?.reasonOfRejection && (
                                <Tooltip title={application?.reasonOfRejection} placement="top" arrow>
                                    <IconButton color="error" size="small">
                                        <MessageOutlined fontSize="small" />
                                    </IconButton>
                                </Tooltip>
                            )}

                            <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
                                {onView && (
                                    <MenuItem onClick={(e) => { handleMenuClose(e); onView(application); }}>View Details</MenuItem>
                                )}

                                {/* 1. Branch Submit */}
                                {userRole === 'BR' && !application.isApplicationSubmittedBR && (
                                    <MenuItem onClick={(e) => { handleMenuClose(e); onSubmitBR(application); }}>Submit Application</MenuItem>
                                )}

                                {/* Verify Menu Option */}
                                {onVerify && (
                                    (application?.isReviewByRO === null && userRole === 'RO') || 
                                    (application?.isReviewByZO === null && userRole === 'ZO') || 
                                    (application?.isReviewByCO === null && userRole === 'CO')
                                ) && (
                                    <MenuItem onClick={(e) => { handleMenuClose(e); onVerify(application); }}>Verify Application</MenuItem>
                                )}

                                {/* Projection Table Popup */}
                                {userRole === 'CO' && application.isReviewByCO === true && !application.isProjectionAdded && (
                                    <MenuItem onClick={(e) => { handleMenuClose(e); onEditProjections(application); }}>Update Projections</MenuItem>
                                )}

                                {/* 8. Final Approval / Download PO */}
                                {application?.isFinalApproved && (
                                    <MenuItem onClick={(e) => {
                                        handleMenuClose(e);
                                        onDownloadPO(application);
                                    }}>Download PO</MenuItem>
                                )}
                                <MenuItem onClick={handleMenuClose}>Close Menu</MenuItem>
                            </Menu>
                        </Box>
                    </TableCell>
                </TableRow>

                {/* Expanded Details */}
                {isExpanded && (
                    <TableRow sx={{ p: 0, backgroundColor: '#fcfcfc' }}>
                        <TableCell colSpan={10} sx={{ py: 2 }}>
                            <Box sx={{ pl: 5, pr: 2 }}>
                                <RoleBasedStepper steps={PAYMENT_AGGREGATOR_WORKFLOW(application)} statusChip />
                            </Box>
                        </TableCell>
                    </TableRow>
                )}
            </Fragment>
        );
    }
);
ApplicationRow.displayName = 'ApplicationRow';

export default ApplicationRow;
